Thanks for downloading!

To install:
Drop the .blueprint file into your pterodactyl root folder (normally /var/www/pterodactyl/)
command line run `blueprint -i nightadmin`

to remove run
`blueprint -remove nightadmin`

Support might be provided but this is a free resource so no promises on quick response, contact me on discord:
jggunter#0