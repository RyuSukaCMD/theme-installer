# Snowflakes
- by prpl.wtf and contributors


To install this Pterodactyl modification, you'll need Blueprint.
Learn more over on https://blueprint.zip.

Once you've installed Blueprint, drag and drop the
"snowflakes.blueprint" file over to your Pterodactyl folder
(commonly /var/www/pterodactyl) and run "blueprint -install snowflakes".